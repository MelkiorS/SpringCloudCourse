package com.luxoft.training.spring.cloud;

public interface Client {
    Integer getId();
    String getName();
}
